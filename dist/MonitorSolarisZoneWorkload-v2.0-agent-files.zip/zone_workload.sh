#!/bin/ksh
#set -x
# a shell script to display basic workload information on the various zones on this system
# based off of prstat -Z and zoneadm

# ideal output is like so

# zones_running 5
# css1\.cpu 5
# css1\.mem 1000
# css1\.rss 2000
# css2\.cpu 25 
# css2\.mem 2000
# css2\.rss 8000
# css3\.cpu 40
# css3\.mem 3000
# css3\.rss 7500

AWKBIN="nawk"
PRSTAT="prstat -Z"
ZONEADM="/usr/sbin/zoneadm list -iv"
TMPFILE="/opt/uptime-agent/$$.tmp"
TMPFILE2="/opt/uptime-agent/$$.tmp2"

# first add up the running zones

ZR=`$ZONEADM | grep running | wc -l`
echo "zones_running $ZR"


# now the trickey part
# we need to get our workload information from the interactive tool prstat
# to do this, run prstat in the background with output to a set file
# find the pid for prstat, kill the process after 2 secs, parse output
# easier than it sounds

`$PRSTAT > $TMPFILE &`
PID=`ps -ef | grep "$PRSTAT" | grep -v 'grep' | $AWKBIN '{print $2}'`
sleep 2
`kill $PID`

# keep only those lines that contain 8 columns and not the word ZONEID
`cat $TMPFILE | grep -v 'ZONEID' | grep -v 'PID' | $AWKBIN '{if (NF=="8") print $0;}' >$TMPFILE2 `

cat $TMPFILE2 | while read ZONEID NPROC SIZE RSS MEMORY TIME CPU ZONE 
do

#SIZE2=`echo $SIZE | $AWKBIN '{ print $5 }' | $AWKBIN 'BEGIN { f=0 } {b=substr($1,0,index($1,"K")-1); if ( b != "" ) {f=b} else {b=substr($1,0,index($1,"M")-1); { if (b!="") {f=b*1024} else {b=substr($1,0,index($1,"G")-1); if (b!="") {f=b*1024*1024} else {f=$1/1024}}}} print f}'`

#RSS2=`echo $RSS | $AWKBIN '{ print $5 }' | $AWKBIN 'BEGIN { f=0 } {b=substr($1,0,index($1,"K")-1); if ( b != "" ) {f=b} else {b=substr($1,0,index($1,"M")-1); { if (b!="") {f=b*1024} else {b=substr($1,0,index($1,"G")-1); if (b!="") {f=b*1024*1024} else {f=$1/1024}}}} print f}'`

CPU=`echo $CPU | sed s/%//`
SIZE=`echo $SIZE | sed s/M//`
RSS=`echo $RSS | sed s/M//` 

echo ${ZONE}.cpu $CPU
echo ${ZONE}.mem $SIZE
echo ${ZONE}.rss $RSS
echo ${ZONE}.procs $NPROC
done

rm $TMPFILE
rm $TMPFILE2
exit 0
