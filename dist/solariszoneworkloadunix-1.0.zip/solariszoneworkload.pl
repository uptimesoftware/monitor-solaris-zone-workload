#!/usr/bin/perl

# Uptime Variables

my $AGENT_HOSTNAME = $ENV{UPTIME_HOSTNAME};
my $AGENT_PASS = $ENV{UPTIME_PASSWORD};
my $AGENT_PORT = $ENV{UPTIME_PORT};
my $NETCAT;
my $TMP_FILE;

# Set some defaults, these will need to change depending on platform


if (-e "/etc/hosts")
{
$NETCAT = "../agentcmd";
$TMP_FILE = "solariszoneworkload.${AGENT_HOSTNAME}.$$";
}
else 
{
$NETCAT = "..\\agentcmd";
$TMP_FILE = "solariszoneworkload.${AGENT_HOSTNAME}.$$";
}


# Processing begins

# Contact agent and save output
$CMD="$NETCAT -p $AGENT_PORT $AGENT_HOSTNAME rexec $AGENT_PASS /opt/uptime-agent/scripts/zone_workload.sh > $TMP_FILE";
`$CMD`;
#print "$CMD";
open( FH, $TMP_FILE );
while ( <FH> ) {

print "$_"

}
unlink($TMP_FILE);
exit ( 0 );
