Solaris Workload Plugin Monitor

This monitor will show you how much each container is using of the physical cpu usage.

The agent side script must be installed on the global zone, which is included in this .zip archive (.\agent).  Installation instructions for the agent can be found in the agent directory.
