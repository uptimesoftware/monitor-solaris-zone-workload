#!/bin/sh

../../apache/bin/php zone_workload-ms.php
