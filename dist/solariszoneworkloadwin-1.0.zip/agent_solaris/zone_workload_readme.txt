1. Installation on agent side systems

Agent Side installations:

On unix systems:

1. Place file in /opt/uptime-agent/scripts 
2. Make sure the zone_workload.sh is executable by the uptime user
3. For example by default nobody
4. Create .uptmpasswd in /opt/uptime-agent/bin
with contents

secret /opt/uptime-agent/scripts/zone_workload.sh

where secret is the password 
